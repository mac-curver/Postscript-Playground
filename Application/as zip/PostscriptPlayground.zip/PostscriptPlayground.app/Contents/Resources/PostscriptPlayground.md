#  Postscript Playground

## Topics

- generating .ps files
- reading .ps files
- using basic syntax coloring

Version: 2.19   2026-01-31
